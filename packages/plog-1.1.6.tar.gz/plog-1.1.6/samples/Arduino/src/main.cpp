#include <Arduino.h>
#include <plog/Log.h>

void setup()
{
}

void loop()
{
    delay(1000); // Wait for a second
}
