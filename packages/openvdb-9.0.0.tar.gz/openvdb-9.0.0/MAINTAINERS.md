<!-- SPDX-License-Identifier: CC-BY-4.0 -->
<!-- Copyright Contributors to the OpenVDB project. -->

# OpenVDB Committers

The current OpenVDB maintainers are:


| Name             | Email |
| ---------------- | -----------------
| Jeff Lait        | jlait@sidefx.com
| Dan Bailey       | danbailey@ilm.com
| Nick Avramoussis | navramoussis@wetafx.co.nz
| Ken Museth       | ken.museth@gmail.com
| Andre Pradhana   | andre.pradhana@dreamworks.com
| Richard Jones    | rhj@dneg.com
